#Copyright (C) 2022 NanyBOT

version= "4.2.5"
copyright = " Nanymous Copyright (C) 2022 Nanymous Team Nany \n\n"
Nanymous = "Nany"

class chup:
	pchap = print(f"Nany library version {version}\n{copyright}\n☞ Nanymous: https://github.com/Nanymous/Nany_library.git\n\n Nany Is Starting...\n")
	print(" ")
	print(". . . . . . . . . . . ")

